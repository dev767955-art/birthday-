const button = document.getElementById("surpriseBtn");
const surprise = document.getElementById("surprise");

button.addEventListener("click", () => {
  surprise.classList.remove("hidden");
  button.textContent = "Surprise Opened 💖";
  button.disabled = true;
  surprise.scrollIntoView({ behavior: "smooth", block: "center" });
});
